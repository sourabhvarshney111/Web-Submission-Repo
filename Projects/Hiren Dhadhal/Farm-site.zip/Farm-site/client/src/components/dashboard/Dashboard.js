import React, { Component } from "react";
// import { Link } from "react-router-dom";
// import PropTypes from "prop-types";
// import { connect } from "react-redux";

class Dashboard extends Component {
  render() {
    return (
      <div>
        <h1>This is product page</h1>
        <h3>Products will be sold here</h3>
      </div>
    );
  }
}

export default Dashboard;
