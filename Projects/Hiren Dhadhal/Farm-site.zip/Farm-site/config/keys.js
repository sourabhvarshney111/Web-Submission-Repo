module.exports = {
  mongoURI:
    "mongodb+srv://hiren:hiren@cluster0-vmwax.mongodb.net/<dbname>?retryWrites=true&w=majority",
  secretOrKey: "secret_company_name",
  adminKey: "admin_secret_key",
  managerKey: "manager_secret_key",
};
